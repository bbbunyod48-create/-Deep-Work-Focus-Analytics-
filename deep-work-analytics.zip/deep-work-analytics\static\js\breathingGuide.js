/**
 * Breathing Guide Overlay
 * ========================
 * Animated breathing circle that guides users through
 * 4-7-8 or box breathing patterns during focus sessions.
 */

const PATTERNS = {
    box: { name: 'Box Breathing', steps: [
        { label: 'Breathe In', duration: 4 },
        { label: 'Hold', duration: 4 },
        { label: 'Breathe Out', duration: 4 },
        { label: 'Hold', duration: 4 },
    ]},
    relaxing: { name: '4-7-8 Relaxing', steps: [
        { label: 'Breathe In', duration: 4 },
        { label: 'Hold', duration: 7 },
        { label: 'Breathe Out', duration: 8 },
    ]},
    focus: { name: 'Focus Breath', steps: [
        { label: 'Breathe In', duration: 5 },
        { label: 'Hold', duration: 2 },
        { label: 'Breathe Out', duration: 5 },
    ]}
};

export class BreathingGuide {
    constructor() {
        this.overlay = null;
        this.isActive = false;
        this.pattern = 'box';
        this.stepIndex = 0;
        this.timer = null;
        this._createOverlay();
    }

    _createOverlay() {
        this.overlay = document.createElement('div');
        this.overlay.className = 'breathing-overlay';
        this.overlay.innerHTML = `
            <div class="breathing-content">
                <div class="breathing-circle-container">
                    <div class="breathing-circle" id="breathingCircle">
                        <div class="breathing-inner">
                            <span class="breathing-label" id="breathingLabel">Breathe In</span>
                            <span class="breathing-timer" id="breathingTimer">4</span>
                        </div>
                    </div>
                    <svg class="breathing-ring" viewBox="0 0 200 200">
                        <circle cx="100" cy="100" r="90" fill="none" stroke="rgba(0,245,212,0.1)" stroke-width="2"/>
                        <circle cx="100" cy="100" r="90" fill="none" stroke="var(--neon-teal)" stroke-width="2"
                            stroke-dasharray="565.48" stroke-dashoffset="565.48" stroke-linecap="round"
                            id="breathingProgress" transform="rotate(-90 100 100)"/>
                    </svg>
                </div>
                <div class="breathing-controls">
                    <select class="breathing-pattern-select" id="breathingPatternSelect">
                        <option value="box">Box Breathing</option>
                        <option value="relaxing">4-7-8 Relaxing</option>
                        <option value="focus">Focus Breath</option>
                    </select>
                    <button class="btn btn--secondary breathing-close" id="breathingClose">Close</button>
                </div>
            </div>
        `;
        document.body.appendChild(this.overlay);

        document.getElementById('breathingClose').addEventListener('click', () => this.hide());
        document.getElementById('breathingPatternSelect').addEventListener('change', (e) => {
            this.pattern = e.target.value;
            if (this.isActive) { this._stop(); this._start(); }
        });
    }

    show() {
        this.overlay.classList.add('active');
        this.isActive = true;
        this._start();
    }

    hide() {
        this.overlay.classList.remove('active');
        this.isActive = false;
        this._stop();
    }

    toggle() {
        if (this.isActive) this.hide(); else this.show();
    }

    _start() {
        this.stepIndex = 0;
        this._runStep();
    }

    _stop() {
        clearTimeout(this.timer);
    }

    _runStep() {
        if (!this.isActive) return;
        const pat = PATTERNS[this.pattern];
        const step = pat.steps[this.stepIndex % pat.steps.length];

        const label = document.getElementById('breathingLabel');
        const timerEl = document.getElementById('breathingTimer');
        const circle = document.getElementById('breathingCircle');
        const progress = document.getElementById('breathingProgress');

        label.textContent = step.label;

        // Animate circle size
        if (step.label.includes('In')) {
            circle.style.transform = 'scale(1.3)';
        } else if (step.label.includes('Out')) {
            circle.style.transform = 'scale(0.8)';
        } else {
            // Hold — keep current
        }

        // Animate progress ring
        const circumference = 565.48;
        progress.style.transition = `stroke-dashoffset ${step.duration}s linear`;
        progress.style.strokeDashoffset = '0';

        // Countdown
        let remaining = step.duration;
        timerEl.textContent = remaining;
        const countInterval = setInterval(() => {
            remaining--;
            if (remaining >= 0) timerEl.textContent = remaining;
        }, 1000);

        this.timer = setTimeout(() => {
            clearInterval(countInterval);
            progress.style.transition = 'none';
            progress.style.strokeDashoffset = circumference;

            this.stepIndex++;
            requestAnimationFrame(() => this._runStep());
        }, step.duration * 1000);
    }
}
