/**
 * Achievements & Streaks System
 * ===============================
 * Gamified badge system that rewards consistent deep work.
 * Tracks milestones and displays unlockable achievements.
 */

const ACHIEVEMENTS = [
    { id: 'first_session', title: 'First Step', desc: 'Complete your first focus session', icon: '🎯', condition: s => s.totalSessions >= 1 },
    { id: 'five_sessions', title: 'Getting Started', desc: 'Complete 5 focus sessions', icon: '⚡', condition: s => s.totalSessions >= 5 },
    { id: 'twenty_sessions', title: 'Consistent', desc: 'Complete 20 focus sessions', icon: '🔥', condition: s => s.totalSessions >= 20 },
    { id: 'fifty_sessions', title: 'Dedicated', desc: 'Complete 50 sessions', icon: '💎', condition: s => s.totalSessions >= 50 },
    { id: 'hundred_sessions', title: 'Master Focus', desc: 'Complete 100 sessions', icon: '👑', condition: s => s.totalSessions >= 100 },
    { id: 'hour_focus', title: 'Deep Diver', desc: 'Accumulate 1 hour of focus', icon: '🌊', condition: s => s.totalMinutes >= 60 },
    { id: 'five_hours', title: 'Time Bender', desc: 'Accumulate 5 hours of focus', icon: '⏳', condition: s => s.totalMinutes >= 300 },
    { id: 'twenty_hours', title: 'Flow Master', desc: 'Accumulate 20 hours of focus', icon: '🧘', condition: s => s.totalMinutes >= 1200 },
    { id: 'streak_3', title: 'Three-peat', desc: 'Maintain a 3-day streak', icon: '🌟', condition: s => s.streak >= 3 },
    { id: 'streak_7', title: 'Weekly Warrior', desc: '7-day focus streak', icon: '⭐', condition: s => s.streak >= 7 },
    { id: 'streak_14', title: 'Fortnight Force', desc: '14-day focus streak', icon: '🌙', condition: s => s.streak >= 14 },
    { id: 'streak_30', title: 'Monthly Legend', desc: '30-day focus streak', icon: '☀️', condition: s => s.streak >= 30 },
    { id: 'bonsai_stage_3', title: 'Green Thumb', desc: 'Grow Bonsai to stage 3', icon: '🌱', condition: s => s.bonsaiStage >= 3 },
    { id: 'bonsai_stage_5', title: 'Bonsai Master', desc: 'Grow Bonsai to stage 5', icon: '🌳', condition: s => s.bonsaiStage >= 5 },
    { id: 'no_distraction', title: 'Laser Focus', desc: 'Complete a session with 0 distractions', icon: '🎯', condition: s => s.zerDistractionSessions >= 1 },
    { id: 'long_session', title: 'Marathon Mind', desc: 'Complete a 60-min session', icon: '🏃', condition: s => s.longestSession >= 60 },
];

export class AchievementSystem {
    constructor() {
        this.unlocked = JSON.parse(localStorage.getItem('dw_achievements') || '[]');
        this.notifContainer = document.getElementById('notificationContainer');
    }

    check(stats) {
        for (const ach of ACHIEVEMENTS) {
            if (this.unlocked.includes(ach.id)) continue;
            try {
                if (ach.condition(stats)) {
                    this.unlocked.push(ach.id);
                    this._save();
                    this._showUnlock(ach);
                }
            } catch (e) { /* condition may fail if stats incomplete */ }
        }
    }

    _save() {
        localStorage.setItem('dw_achievements', JSON.stringify(this.unlocked));
    }

    _showUnlock(ach) {
        const notif = document.createElement('div');
        notif.className = 'notification notification--success';
        notif.innerHTML = `
            <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:1.8rem">${ach.icon}</span>
                <div>
                    <div style="font-weight:700;letter-spacing:2px;font-size:0.7rem;color:var(--neon-teal)">ACHIEVEMENT UNLOCKED</div>
                    <div style="font-size:1rem;margin-top:4px">${ach.title}</div>
                    <div style="font-size:0.75rem;opacity:0.6;margin-top:2px">${ach.desc}</div>
                </div>
            </div>`;
        this.notifContainer.appendChild(notif);
        requestAnimationFrame(() => notif.classList.add('show'));
        setTimeout(() => {
            notif.classList.remove('show');
            setTimeout(() => notif.remove(), 500);
        }, 5000);
    }

    getAll() {
        return ACHIEVEMENTS.map(a => ({
            ...a,
            unlocked: this.unlocked.includes(a.id)
        }));
    }

    getUnlockedCount() {
        return this.unlocked.length;
    }

    getTotalCount() {
        return ACHIEVEMENTS.length;
    }

    /** Render achievements grid into a container element */
    renderGrid(container) {
        container.innerHTML = '';
        const all = this.getAll();
        for (const ach of all) {
            const card = document.createElement('div');
            card.className = `achievement-card ${ach.unlocked ? 'unlocked' : 'locked'}`;
            card.innerHTML = `
                <span class="achievement-icon">${ach.icon}</span>
                <span class="achievement-title">${ach.title}</span>
                <span class="achievement-desc">${ach.desc}</span>
            `;
            container.appendChild(card);
        }
    }
}
