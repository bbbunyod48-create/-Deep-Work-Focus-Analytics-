/**
 * 3D Isometric Focus Analytics Grid
 * ===================================
 * Fetches analytics data and renders an isometric bar chart
 * with CSS 3D perspective transforms and animated counters.
 */

export class AnalyticsGrid {
    constructor() {
        this.grid = document.getElementById('isometricGrid');
        this.wrapper = document.getElementById('isometricWrapper');
        this.data = [];
        this.animated = false;
        this._setupObserver();
    }

    async loadData() {
        try {
            const res = await fetch('/api/analytics?days=90');
            if (res.ok) {
                const json = await res.json();
                this.data = json.daily || [];
                this._updateSummary(json.summary, json.streak);
                this._renderGrid();
            }
        } catch (e) {
            console.warn('Analytics load failed:', e);
        }
    }

    _updateSummary(summary, streak) {
        const totalHours = Math.round((summary.total_seconds || 0) / 3600);
        const avgMin = Math.round((summary.avg_duration || 0) / 60);
        const sessions = summary.total_sessions || 0;

        this._setCounter('summaryTotalHours', totalHours);
        this._setCounter('summaryStreak', streak || 0);
        this._setCounter('summarySessions', sessions);
        this._setCounter('summaryAvgDuration', avgMin);
    }

    _setCounter(id, target) {
        const el = document.getElementById(id);
        if (!el) return;
        const valueEl = el.querySelector('.summary-value');
        if (!valueEl) return;
        valueEl.setAttribute('data-target', target);
    }

    _animateCounters() {
        const counters = document.querySelectorAll('.counter');
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target')) || 0;
            const duration = 1500;
            const start = performance.now();

            const update = (now) => {
                const elapsed = now - start;
                const progress = Math.min(elapsed / duration, 1);
                // Ease out cubic
                const eased = 1 - Math.pow(1 - progress, 3);
                counter.textContent = Math.round(eased * target);
                if (progress < 1) requestAnimationFrame(update);
            };
            requestAnimationFrame(update);
        });
    }

    _renderGrid() {
        this.grid.innerHTML = '';
        const maxSeconds = Math.max(...this.data.map(d => d.total_seconds || 0), 1);

        this.data.forEach((day, i) => {
            const col = document.createElement('div');
            col.className = 'iso-column';

            const bar = document.createElement('div');
            bar.className = 'iso-bar';

            const seconds = day.total_seconds || 0;
            const heightPercent = (seconds / maxSeconds) * 100;
            const maxHeight = 120; // px
            const barHeight = Math.max(2, (heightPercent / 100) * maxHeight);

            // Color gradient based on intensity
            const intensity = seconds / maxSeconds;
            let color;
            if (intensity < 0.33) {
                color = '#b24bf3'; // violet
            } else if (intensity < 0.66) {
                color = '#ff6b35'; // amber
            } else {
                color = '#00f5d4'; // teal
            }

            bar.style.height = '2px'; // start collapsed
            bar.style.backgroundColor = color;
            bar.style.boxShadow = `0 0 6px ${color}40`;
            bar.setAttribute('data-height', barHeight);
            bar.setAttribute('data-index', i);

            // Tooltip
            const tooltip = document.createElement('div');
            tooltip.className = 'iso-tooltip';
            const date = new Date(day.date);
            const mins = Math.round(seconds / 60);
            tooltip.textContent = `${date.toLocaleDateString('en', { month: 'short', day: 'numeric' })} — ${mins}min`;
            bar.appendChild(tooltip);

            col.appendChild(bar);
            this.grid.appendChild(col);
        });
    }

    _setupObserver() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animated) {
                    this.animated = true;
                    this._animateIn();
                }
            });
        }, { threshold: 0.2 });

        if (this.wrapper) observer.observe(this.wrapper);
    }

    _animateIn() {
        const bars = this.grid.querySelectorAll('.iso-bar');
        bars.forEach((bar, i) => {
            const targetHeight = bar.getAttribute('data-height') || 2;
            setTimeout(() => {
                bar.style.height = targetHeight + 'px';
            }, i * 12);
        });
        this._animateCounters();
    }

    /** Call when section becomes visible to trigger animations */
    show() {
        if (!this.animated) {
            this.loadData().then(() => {
                setTimeout(() => this._animateIn(), 300);
            });
        }
    }

    /** Reset animation state so it re-triggers on next view */
    reset() {
        this.animated = false;
    }
}
