/**
 * Bonsai Guardian — SVG Bonsai Tree + Page Visibility API
 * ========================================================
 * Procedurally generates an SVG bonsai tree that grows during focus.
 * Detects tab switches via Page Visibility API and penalizes with leaf loss.
 */

export class BonsaiGuardian {
    constructor() {
        this.svg = document.getElementById('bonsaiSvg');
        this.group = document.getElementById('bonsaiGroup');
        this.glitchOverlay = document.getElementById('glitchOverlay');
        this.healthFill = document.getElementById('healthBarFill');
        this.healthVal = document.getElementById('healthValue');
        this.leavesVal = document.getElementById('leavesValue');
        this.stageVal = document.getElementById('stageValue');
        this.focusVal = document.getElementById('totalFocusValue');
        this.notifContainer = document.getElementById('notificationContainer');

        this.state = { health: 100, leaves: 50, growth_stage: 1, total_focus_minutes: 0 };
        this.leafElements = [];
        this.isHidden = false;
        this.glitchTimeout = null;

        this._bindVisibility();
        this._loadState();
    }

    async _loadState() {
        try {
            const res = await fetch('/api/bonsai');
            if (res.ok) this.state = await res.json();
        } catch (e) { /* use defaults */ }
        this._renderTree();
        this._updateUI();
    }

    async _saveState() {
        try {
            await fetch('/api/bonsai', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    health: this.state.health,
                    leaves: this.state.leaves,
                    growth_stage: this.state.growth_stage,
                    total_focus_minutes: this.state.total_focus_minutes
                })
            });
        } catch (e) { /* silent */ }
    }

    _bindVisibility() {
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this._onTabLeave();
            } else {
                this._onTabReturn();
            }
        });
    }

    _onTabLeave() {
        this.isHidden = true;
        this.glitchOverlay.classList.add('active');
        // Lose leaves
        const lostLeaves = Math.min(3 + Math.floor(Math.random() * 4), this.state.leaves);
        this.state.leaves = Math.max(0, this.state.leaves - lostLeaves);
        this.state.health = Math.max(0, this.state.health - 5);
        this._removeLeaves(lostLeaves);
        this._updateUI();
        this._saveState();
    }

    _onTabReturn() {
        if (!this.isHidden) return;
        this.isHidden = false;
        this.glitchOverlay.classList.remove('active');
        this._showNotification(
            `⚠ Focus broken! Your Bonsai lost leaves. ${this.state.leaves} remaining.`,
            'warning'
        );
    }

    _showNotification(message, type = 'info') {
        const notif = document.createElement('div');
        notif.className = `notification notification--${type}`;
        notif.textContent = message;
        this.notifContainer.appendChild(notif);
        requestAnimationFrame(() => notif.classList.add('show'));
        setTimeout(() => {
            notif.classList.remove('show');
            setTimeout(() => notif.remove(), 500);
        }, 4000);
    }

    _renderTree() {
        this.group.innerHTML = '';
        this.leafElements = [];
        const depth = Math.min(this.state.growth_stage + 4, 9);
        this._drawBranch(300, 460, -Math.PI / 2, depth, 60 + this.state.growth_stage * 5, 12);
    }

    _drawBranch(x, y, angle, depth, length, width) {
        if (depth <= 0) {
            this._addLeaf(x, y);
            return;
        }

        const endX = x + Math.cos(angle) * length;
        const endY = y + Math.sin(angle) * length;

        const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        line.setAttribute('x1', x);
        line.setAttribute('y1', y);
        line.setAttribute('x2', endX);
        line.setAttribute('y2', endY);
        line.setAttribute('stroke', depth > 3 ? '#8B6914' : '#6B8E23');
        line.setAttribute('stroke-width', Math.max(width, 1));
        line.setAttribute('stroke-linecap', 'round');
        line.setAttribute('opacity', '0.9');
        this.group.appendChild(line);

        // Animate branch drawing
        const len = Math.sqrt((endX - x) ** 2 + (endY - y) ** 2);
        line.setAttribute('stroke-dasharray', len);
        line.setAttribute('stroke-dashoffset', len);
        line.style.transition = `stroke-dashoffset ${0.3 + depth * 0.1}s ease ${(9 - depth) * 0.15}s`;
        requestAnimationFrame(() => line.setAttribute('stroke-dashoffset', '0'));

        const spread = 0.35 + Math.random() * 0.25;
        const shrink = 0.65 + Math.random() * 0.1;
        this._drawBranch(endX, endY, angle - spread, depth - 1, length * shrink, width * 0.7);
        this._drawBranch(endX, endY, angle + spread, depth - 1, length * shrink, width * 0.7);
        if (depth > 4 && Math.random() > 0.5) {
            this._drawBranch(endX, endY, angle + (Math.random() - 0.5) * 0.3, depth - 2, length * 0.5, width * 0.5);
        }
    }

    _addLeaf(x, y) {
        if (this.leafElements.length >= this.state.leaves) return;
        const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
        circle.setAttribute('cx', x + (Math.random() - 0.5) * 10);
        circle.setAttribute('cy', y + (Math.random() - 0.5) * 10);
        circle.setAttribute('r', 3 + Math.random() * 4);
        circle.setAttribute('fill', 'url(#leafGradient)');
        circle.setAttribute('filter', 'url(#glowFilter)');
        circle.setAttribute('opacity', '0');
        circle.style.transition = `opacity 0.5s ease ${Math.random() * 2}s`;
        this.group.appendChild(circle);
        this.leafElements.push(circle);
        requestAnimationFrame(() => circle.setAttribute('opacity', String(0.5 + Math.random() * 0.5)));
    }

    _removeLeaves(count) {
        for (let i = 0; i < count && this.leafElements.length > 0; i++) {
            const idx = Math.floor(Math.random() * this.leafElements.length);
            const leaf = this.leafElements.splice(idx, 1)[0];
            if (leaf) {
                leaf.style.transition = 'opacity 0.5s ease, transform 1s ease';
                leaf.setAttribute('opacity', '0');
                leaf.style.transform = `translateY(40px)`;
                setTimeout(() => leaf.remove(), 1000);
            }
        }
    }

    _updateUI() {
        this.healthFill.style.width = this.state.health + '%';
        this.healthVal.textContent = this.state.health + '%';
        this.leavesVal.textContent = this.state.leaves;
        this.stageVal.textContent = this.state.growth_stage;
        const hrs = (this.state.total_focus_minutes / 60).toFixed(1);
        this.focusVal.textContent = hrs + 'h';

        // Color health bar based on value
        if (this.state.health > 60) {
            this.healthFill.style.background = 'linear-gradient(90deg,var(--neon-teal),#6ee7b7)';
        } else if (this.state.health > 30) {
            this.healthFill.style.background = 'linear-gradient(90deg,var(--volcanic-amber),#fbbf24)';
        } else {
            this.healthFill.style.background = 'linear-gradient(90deg,var(--neon-pink),var(--volcanic-amber))';
        }
    }

    /** Call when a focus session completes to grow the tree */
    addFocusMinutes(minutes) {
        this.state.total_focus_minutes += minutes;
        this.state.leaves = Math.min(this.state.leaves + Math.floor(minutes / 5), 120);
        this.state.health = Math.min(this.state.health + Math.floor(minutes / 3), 100);
        if (this.state.total_focus_minutes > this.state.growth_stage * 120) {
            this.state.growth_stage = Math.min(this.state.growth_stage + 1, 6);
        }
        this._renderTree();
        this._updateUI();
        this._saveState();
        this._showNotification(
            `🌳 +${minutes} min focus! Your Bonsai grows stronger.`,
            'success'
        );
    }
}
