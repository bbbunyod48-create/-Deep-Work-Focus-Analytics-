"""
Deep Work & Focus Analytics — FastAPI Backend
==============================================
Serves the frontend static files and provides REST API
endpoints for session tracking, task management, and
bonsai tree state persistence via SQLite.
"""

import sqlite3
import json
import os
from datetime import datetime, timedelta
from contextlib import contextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Optional

# ──────────────────────────────────────────────
# Database Setup
# ──────────────────────────────────────────────

DB_PATH = Path(__file__).parent / "deepwork.db"

def get_db():
    """Create a database connection with row factory."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    """Initialize database tables if they don't exist."""
    conn = get_db()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time TEXT NOT NULL,
            end_time TEXT,
            duration_seconds INTEGER DEFAULT 0,
            target_minutes INTEGER DEFAULT 25,
            completed BOOLEAN DEFAULT 0,
            distractions INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            category TEXT DEFAULT 'general',
            sort_order INTEGER DEFAULT 0,
            completed BOOLEAN DEFAULT 0,
            session_id INTEGER,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (session_id) REFERENCES sessions(id)
        );

        CREATE TABLE IF NOT EXISTS bonsai_state (
            id INTEGER PRIMARY KEY DEFAULT 1,
            health INTEGER DEFAULT 100,
            leaves INTEGER DEFAULT 50,
            growth_stage INTEGER DEFAULT 1,
            total_focus_minutes INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        -- Seed bonsai state if empty
        INSERT OR IGNORE INTO bonsai_state (id, health, leaves, growth_stage, total_focus_minutes)
        VALUES (1, 100, 50, 1, 0);
    """)

    # Seed some demo analytics data for the last 90 days
    cursor.execute("SELECT COUNT(*) FROM sessions")
    if cursor.fetchone()[0] == 0:
        _seed_demo_data(cursor)

    conn.commit()
    conn.close()

def _seed_demo_data(cursor):
    """Seed demo session data for visual analytics."""
    import random
    now = datetime.now()
    for i in range(90):
        day = now - timedelta(days=89 - i)
        # Random number of sessions per day (0-4)
        num_sessions = random.choices([0, 1, 2, 3, 4], weights=[15, 30, 30, 15, 10])[0]
        for _ in range(num_sessions):
            duration = random.randint(10, 55) * 60  # 10-55 minutes in seconds
            target = random.choice([15, 25, 45, 60])
            start = day.replace(
                hour=random.randint(8, 20),
                minute=random.randint(0, 59)
            )
            end = start + timedelta(seconds=duration)
            cursor.execute("""
                INSERT INTO sessions (start_time, end_time, duration_seconds, target_minutes, completed, distractions)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                start.isoformat(),
                end.isoformat(),
                duration,
                target,
                1 if duration >= target * 60 * 0.8 else 0,
                random.randint(0, 5)
            ))

# ──────────────────────────────────────────────
# Pydantic Models
# ──────────────────────────────────────────────

class SessionCreate(BaseModel):
    target_minutes: int = 25

class SessionUpdate(BaseModel):
    end_time: Optional[str] = None
    duration_seconds: Optional[int] = None
    completed: Optional[bool] = None
    distractions: Optional[int] = None

class TaskCreate(BaseModel):
    title: str
    category: str = "general"
    session_id: Optional[int] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    sort_order: Optional[int] = None
    completed: Optional[bool] = None

class BonsaiUpdate(BaseModel):
    health: Optional[int] = None
    leaves: Optional[int] = None
    growth_stage: Optional[int] = None
    total_focus_minutes: Optional[int] = None

# ──────────────────────────────────────────────
# FastAPI Application
# ──────────────────────────────────────────────

app = FastAPI(title="Deep Work Analytics", version="1.0.0")

@app.on_event("startup")
async def startup():
    init_db()

# ──────────────────────────────────────────────
# Session Endpoints
# ──────────────────────────────────────────────

@app.post("/api/sessions")
async def create_session(session: SessionCreate):
    conn = get_db()
    cursor = conn.cursor()
    now = datetime.now().isoformat()
    cursor.execute(
        "INSERT INTO sessions (start_time, target_minutes) VALUES (?, ?)",
        (now, session.target_minutes)
    )
    conn.commit()
    session_id = cursor.lastrowid
    conn.close()
    return {"id": session_id, "start_time": now, "target_minutes": session.target_minutes}

@app.get("/api/sessions")
async def list_sessions(limit: int = 50, offset: int = 0):
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM sessions ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (limit, offset)
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]

@app.put("/api/sessions/{session_id}")
async def update_session(session_id: int, data: SessionUpdate):
    conn = get_db()
    updates = []
    values = []
    for field, value in data.dict(exclude_none=True).items():
        updates.append(f"{field} = ?")
        values.append(value)

    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    values.append(session_id)
    conn.execute(
        f"UPDATE sessions SET {', '.join(updates)} WHERE id = ?",
        values
    )
    conn.commit()
    row = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Session not found")
    return dict(row)

# ──────────────────────────────────────────────
# Analytics Endpoint
# ──────────────────────────────────────────────

@app.get("/api/analytics")
async def get_analytics(days: int = 90):
    conn = get_db()
    cutoff = (datetime.now() - timedelta(days=days)).isoformat()

    # Daily aggregation
    daily = conn.execute("""
        SELECT
            DATE(start_time) as date,
            SUM(duration_seconds) as total_seconds,
            COUNT(*) as session_count,
            SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END) as completed_count,
            SUM(distractions) as total_distractions
        FROM sessions
        WHERE start_time >= ?
        GROUP BY DATE(start_time)
        ORDER BY date ASC
    """, (cutoff,)).fetchall()

    # Summary stats
    summary = conn.execute("""
        SELECT
            COALESCE(SUM(duration_seconds), 0) as total_seconds,
            COUNT(*) as total_sessions,
            COALESCE(SUM(CASE WHEN completed = 1 THEN 1 ELSE 0 END), 0) as completed_sessions,
            COALESCE(AVG(duration_seconds), 0) as avg_duration
        FROM sessions
        WHERE start_time >= ?
    """, (cutoff,)).fetchone()

    conn.close()

    # Build complete date range (fill gaps with zeros)
    date_map = {row["date"]: dict(row) for row in daily}
    complete_daily = []
    for i in range(days):
        d = (datetime.now() - timedelta(days=days - 1 - i)).strftime("%Y-%m-%d")
        if d in date_map:
            complete_daily.append(date_map[d])
        else:
            complete_daily.append({
                "date": d,
                "total_seconds": 0,
                "session_count": 0,
                "completed_count": 0,
                "total_distractions": 0
            })

    # Calculate current streak
    streak = 0
    for entry in reversed(complete_daily):
        if entry["session_count"] > 0:
            streak += 1
        else:
            break

    return {
        "daily": complete_daily,
        "summary": dict(summary),
        "streak": streak
    }

# ──────────────────────────────────────────────
# Task Endpoints
# ──────────────────────────────────────────────

@app.post("/api/tasks")
async def create_task(task: TaskCreate):
    conn = get_db()
    cursor = conn.cursor()
    # Get max sort_order
    max_order = conn.execute("SELECT COALESCE(MAX(sort_order), 0) FROM tasks").fetchone()[0]
    cursor.execute(
        "INSERT INTO tasks (title, category, sort_order, session_id) VALUES (?, ?, ?, ?)",
        (task.title, task.category, max_order + 1, task.session_id)
    )
    conn.commit()
    task_id = cursor.lastrowid
    row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    conn.close()
    return dict(row)

@app.get("/api/tasks")
async def list_tasks():
    conn = get_db()
    rows = conn.execute("SELECT * FROM tasks ORDER BY sort_order ASC").fetchall()
    conn.close()
    return [dict(row) for row in rows]

@app.put("/api/tasks/{task_id}")
async def update_task(task_id: int, data: TaskUpdate):
    conn = get_db()
    updates = []
    values = []
    for field, value in data.dict(exclude_none=True).items():
        updates.append(f"{field} = ?")
        values.append(value)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    values.append(task_id)
    conn.execute(f"UPDATE tasks SET {', '.join(updates)} WHERE id = ?", values)
    conn.commit()
    row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Task not found")
    return dict(row)

@app.delete("/api/tasks/{task_id}")
async def delete_task(task_id: int):
    conn = get_db()
    conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()
    return {"deleted": True}

# ──────────────────────────────────────────────
# Bonsai State Endpoints
# ──────────────────────────────────────────────

@app.get("/api/bonsai")
async def get_bonsai():
    conn = get_db()
    row = conn.execute("SELECT * FROM bonsai_state WHERE id = 1").fetchone()
    conn.close()
    return dict(row)

@app.put("/api/bonsai")
async def update_bonsai(data: BonsaiUpdate):
    conn = get_db()
    updates = []
    values = []
    for field, value in data.dict(exclude_none=True).items():
        updates.append(f"{field} = ?")
        values.append(value)
    if updates:
        updates.append("updated_at = ?")
        values.append(datetime.now().isoformat())
        conn.execute(f"UPDATE bonsai_state SET {', '.join(updates)} WHERE id = 1", values)
        conn.commit()
    row = conn.execute("SELECT * FROM bonsai_state WHERE id = 1").fetchone()
    conn.close()
    return dict(row)

# ──────────────────────────────────────────────
# Static Files & SPA Fallback
# ──────────────────────────────────────────────

STATIC_DIR = Path(__file__).parent / "static"

@app.get("/")
async def serve_index():
    return FileResponse(STATIC_DIR / "index.html")

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
