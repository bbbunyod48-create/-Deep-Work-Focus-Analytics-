/**
 * Binaural Audio Matrix — Web Audio API Synthesizer
 * ==================================================
 * Generates real-time soundscapes (Rain, Binaural Beats, Deep Space, White Noise)
 * using the Web Audio API. Users drag a listener node on a 2D canvas grid,
 * and proximity to sound source nodes controls the mix.
 */

export class AudioMatrix {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.audioCtx = null;
        this.isActive = false;
        this.sources = {};
        this.time = 0;
        this.ripples = [];

        // Sound source positions (normalized 0-1)
        this.nodes = {
            rain:     { x: 0.15, y: 0.15, label: 'Rain',     color: '#00f5d4', icon: '🌧️' },
            binaural: { x: 0.85, y: 0.15, label: 'Binaural', color: '#b24bf3', icon: '🧠' },
            space:    { x: 0.15, y: 0.85, label: 'Deep Space',color: '#ff6b35', icon: '🌌' },
            noise:    { x: 0.85, y: 0.85, label: 'White Noise',color: '#e8e8f0', icon: '📡' }
        };

        // Listener (draggable) position
        this.listener = { x: 0.5, y: 0.5 };
        this.isDragging = false;
        this.gains = { rain: 0, binaural: 0, space: 0, noise: 0 };

        this._bindEvents();
        this._resize();
        this._animate = this._animate.bind(this);
        requestAnimationFrame(this._animate);
    }

    _resize() {
        const wrapper = this.canvas.parentElement;
        const size = Math.min(wrapper.clientWidth, wrapper.clientHeight);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        this.canvas.width = size * dpr;
        this.canvas.height = size * dpr;
        this.canvas.style.width = size + 'px';
        this.canvas.style.height = size + 'px';
        this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        this.displaySize = size;
    }

    _bindEvents() {
        window.addEventListener('resize', () => this._resize());

        const getPos = (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            return {
                x: (clientX - rect.left) / rect.width,
                y: (clientY - rect.top) / rect.height
            };
        };

        const onStart = (e) => {
            const pos = getPos(e);
            const dx = pos.x - this.listener.x;
            const dy = pos.y - this.listener.y;
            if (Math.sqrt(dx * dx + dy * dy) < 0.06) {
                this.isDragging = true;
                e.preventDefault();
            }
        };

        const onMove = (e) => {
            if (!this.isDragging) return;
            e.preventDefault();
            const pos = getPos(e);
            this.listener.x = Math.max(0.05, Math.min(0.95, pos.x));
            this.listener.y = Math.max(0.05, Math.min(0.95, pos.y));
            this._updateGains();
        };

        const onEnd = () => { this.isDragging = false; };

        this.canvas.addEventListener('mousedown', onStart);
        this.canvas.addEventListener('mousemove', onMove);
        this.canvas.addEventListener('mouseup', onEnd);
        this.canvas.addEventListener('touchstart', onStart, { passive: false });
        this.canvas.addEventListener('touchmove', onMove, { passive: false });
        this.canvas.addEventListener('touchend', onEnd);
    }

    async toggle() {
        if (this.isActive) {
            this._stopAudio();
        } else {
            await this._startAudio();
        }
        return this.isActive;
    }

    async _startAudio() {
        this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (this.audioCtx.state === 'suspended') await this.audioCtx.resume();

        // Master gain
        this.masterGain = this.audioCtx.createGain();
        this.masterGain.gain.value = 0.3;
        this.masterGain.connect(this.audioCtx.destination);

        // Create sound sources
        this._createRain();
        this._createBinaural();
        this._createSpace();
        this._createWhiteNoise();

        this._updateGains();
        this.isActive = true;
    }

    _stopAudio() {
        if (this.audioCtx) {
            this.audioCtx.close();
            this.audioCtx = null;
        }
        this.sources = {};
        this.isActive = false;
    }

    _createRain() {
        // Brown noise filtered to sound like rain
        const bufferSize = this.audioCtx.sampleRate * 2;
        const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        let lastOut = 0;
        for (let i = 0; i < bufferSize; i++) {
            const white = Math.random() * 2 - 1;
            data[i] = (lastOut + (0.02 * white)) / 1.02;
            lastOut = data[i];
            data[i] *= 3.5;
        }
        const source = this.audioCtx.createBufferSource();
        source.buffer = buffer;
        source.loop = true;

        const filter = this.audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 800;
        filter.Q.value = 0.5;

        const gain = this.audioCtx.createGain();
        gain.gain.value = 0;
        source.connect(filter).connect(gain).connect(this.masterGain);
        source.start();
        this.sources.rain = { source, gain, filter };
    }

    _createBinaural() {
        const baseFreq = 200;
        const beatFreq = 4; // Theta waves for focus

        const oscL = this.audioCtx.createOscillator();
        const oscR = this.audioCtx.createOscillator();
        oscL.type = 'sine';
        oscR.type = 'sine';
        oscL.frequency.value = baseFreq;
        oscR.frequency.value = baseFreq + beatFreq;

        const panL = this.audioCtx.createStereoPanner();
        const panR = this.audioCtx.createStereoPanner();
        panL.pan.value = -1;
        panR.pan.value = 1;

        const gain = this.audioCtx.createGain();
        gain.gain.value = 0;

        oscL.connect(panL).connect(gain).connect(this.masterGain);
        oscR.connect(panR).connect(gain).connect(this.masterGain);
        oscL.start();
        oscR.start();
        this.sources.binaural = { oscL, oscR, gain };
    }

    _createSpace() {
        const osc = this.audioCtx.createOscillator();
        osc.type = 'sine';
        osc.frequency.value = 55; // Deep drone

        const osc2 = this.audioCtx.createOscillator();
        osc2.type = 'sine';
        osc2.frequency.value = 82.5; // Fifth above

        const gain = this.audioCtx.createGain();
        gain.gain.value = 0;

        const lfo = this.audioCtx.createOscillator();
        lfo.frequency.value = 0.05;
        const lfoGain = this.audioCtx.createGain();
        lfoGain.gain.value = 10;
        lfo.connect(lfoGain).connect(osc.frequency);
        lfo.start();

        osc.connect(gain).connect(this.masterGain);
        osc2.connect(gain).connect(this.masterGain);
        osc.start();
        osc2.start();
        this.sources.space = { osc, osc2, gain, lfo };
    }

    _createWhiteNoise() {
        const bufferSize = this.audioCtx.sampleRate * 2;
        const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        const source = this.audioCtx.createBufferSource();
        source.buffer = buffer;
        source.loop = true;

        const filter = this.audioCtx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 1000;

        const gain = this.audioCtx.createGain();
        gain.gain.value = 0;
        source.connect(filter).connect(gain).connect(this.masterGain);
        source.start();
        this.sources.noise = { source, gain };
    }

    _updateGains() {
        for (const [key, node] of Object.entries(this.nodes)) {
            const dx = this.listener.x - node.x;
            const dy = this.listener.y - node.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const maxDist = 0.9;
            const g = Math.max(0, 1 - dist / maxDist);
            this.gains[key] = g;

            if (this.isActive && this.sources[key]) {
                const targetGain = g * g; // quadratic falloff
                this.sources[key].gain.gain.setTargetAtTime(targetGain, this.audioCtx.currentTime, 0.1);
            }

            // Add ripple when gain is significant
            if (g > 0.3 && Math.random() > 0.95) {
                this.ripples.push({
                    x: node.x, y: node.y, r: 0, maxR: 0.08 + g * 0.06,
                    alpha: g * 0.5, color: node.color
                });
            }
        }

        // Update UI level bars
        for (const [key, g] of Object.entries(this.gains)) {
            const fill = document.querySelector(`.audio-level-fill[data-sound="${key}"]`);
            if (fill) fill.style.width = (g * 100) + '%';
        }
    }

    _animate() {
        this.time += 0.016;
        const ctx = this.ctx;
        const s = this.displaySize;
        ctx.clearRect(0, 0, s, s);

        // Draw grid
        ctx.strokeStyle = 'rgba(255,255,255,0.03)';
        ctx.lineWidth = 1;
        const gridStep = s / 20;
        for (let i = 0; i <= 20; i++) {
            ctx.beginPath();
            ctx.moveTo(i * gridStep, 0);
            ctx.lineTo(i * gridStep, s);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(0, i * gridStep);
            ctx.lineTo(s, i * gridStep);
            ctx.stroke();
        }

        // Draw ripples
        this.ripples = this.ripples.filter(r => {
            r.r += 0.002;
            r.alpha -= 0.008;
            if (r.alpha <= 0) return false;
            ctx.beginPath();
            ctx.arc(r.x * s, r.y * s, r.r * s, 0, Math.PI * 2);
            ctx.strokeStyle = r.color.replace(')', `,${r.alpha})`).replace('rgb', 'rgba').replace('#', '');
            // Convert hex to rgba for stroke
            const hex = r.color;
            const rr = parseInt(hex.slice(1, 3), 16);
            const gg = parseInt(hex.slice(3, 5), 16);
            const bb = parseInt(hex.slice(5, 7), 16);
            ctx.strokeStyle = `rgba(${rr},${gg},${bb},${r.alpha})`;
            ctx.lineWidth = 2;
            ctx.stroke();
            return true;
        });

        // Draw connection lines from listener to sources
        for (const [key, node] of Object.entries(this.nodes)) {
            const g = this.gains[key];
            if (g > 0.01) {
                ctx.beginPath();
                ctx.moveTo(this.listener.x * s, this.listener.y * s);
                ctx.lineTo(node.x * s, node.y * s);
                const hex = node.color;
                const rr = parseInt(hex.slice(1, 3), 16);
                const gg = parseInt(hex.slice(3, 5), 16);
                const bb = parseInt(hex.slice(5, 7), 16);
                ctx.strokeStyle = `rgba(${rr},${gg},${bb},${g * 0.3})`;
                ctx.lineWidth = 1 + g * 2;
                ctx.setLineDash([4, 8]);
                ctx.stroke();
                ctx.setLineDash([]);
            }
        }

        // Draw source nodes
        for (const [key, node] of Object.entries(this.nodes)) {
            const nx = node.x * s;
            const ny = node.y * s;
            const g = this.gains[key];
            const pulse = 1 + Math.sin(this.time * 2 + Object.keys(this.nodes).indexOf(key)) * 0.1;

            // Glow
            const glowGrad = ctx.createRadialGradient(nx, ny, 0, nx, ny, 30 + g * 20);
            const hex = node.color;
            const rr = parseInt(hex.slice(1, 3), 16);
            const gg = parseInt(hex.slice(3, 5), 16);
            const bb = parseInt(hex.slice(5, 7), 16);
            glowGrad.addColorStop(0, `rgba(${rr},${gg},${bb},${0.15 + g * 0.2})`);
            glowGrad.addColorStop(1, 'transparent');
            ctx.fillStyle = glowGrad;
            ctx.fillRect(nx - 50, ny - 50, 100, 100);

            // Node circle
            ctx.beginPath();
            ctx.arc(nx, ny, 14 * pulse, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${rr},${gg},${bb},${0.2 + g * 0.3})`;
            ctx.fill();
            ctx.strokeStyle = node.color;
            ctx.lineWidth = 2;
            ctx.stroke();

            // Label
            ctx.font = '10px "JetBrains Mono"';
            ctx.fillStyle = `rgba(${rr},${gg},${bb},${0.6 + g * 0.4})`;
            ctx.textAlign = 'center';
            ctx.fillText(node.label, nx, ny + 30);

            // Icon
            ctx.font = '18px serif';
            ctx.fillText(node.icon, nx, ny + 6);
        }

        // Draw listener node
        const lx = this.listener.x * s;
        const ly = this.listener.y * s;
        const lPulse = 1 + Math.sin(this.time * 3) * 0.08;

        ctx.beginPath();
        ctx.arc(lx, ly, 18 * lPulse, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.1)';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Crosshair
        ctx.beginPath();
        ctx.moveTo(lx - 8, ly); ctx.lineTo(lx + 8, ly);
        ctx.moveTo(lx, ly - 8); ctx.lineTo(lx, ly + 8);
        ctx.strokeStyle = 'rgba(255,255,255,0.5)';
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.font = '8px "JetBrains Mono"';
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.textAlign = 'center';
        ctx.fillText('LISTENER', lx, ly + 32);

        requestAnimationFrame(this._animate.bind(this));
    }

    destroy() {
        this._stopAudio();
    }
}
