/**
 * Liquid Particle Focus Sphere — Canvas Particle Engine
 * =====================================================
 * 500+ particles form a morphing 3D sphere using Fibonacci distribution.
 * States: idle (swirling), focus (calm breathing), complete (explosion).
 * Mouse velocity adds turbulence to reflect distraction.
 */

const PARTICLE_COUNT = 600;
const TAU = Math.PI * 2;
const PHI = Math.PI * (3 - Math.sqrt(5)); // golden angle

export class ParticleSphere {
    constructor(canvasId, opts = {}) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.state = 'idle'; // idle | focus | paused | complete
        this.time = 0;
        this.turbulence = 0;
        this.mouseVelocity = 0;
        this.lastMouseX = 0;
        this.lastMouseY = 0;
        this.breathPhase = 0;
        this.onComplete = opts.onComplete || (() => {});

        // Pre-allocate typed arrays for performance
        this.px = new Float32Array(PARTICLE_COUNT);
        this.py = new Float32Array(PARTICLE_COUNT);
        this.pz = new Float32Array(PARTICLE_COUNT);
        this.baseX = new Float32Array(PARTICLE_COUNT);
        this.baseY = new Float32Array(PARTICLE_COUNT);
        this.baseZ = new Float32Array(PARTICLE_COUNT);
        this.vx = new Float32Array(PARTICLE_COUNT);
        this.vy = new Float32Array(PARTICLE_COUNT);
        this.sizes = new Float32Array(PARTICLE_COUNT);
        this.alphas = new Float32Array(PARTICLE_COUNT);

        this._initParticles();
        this._bindEvents();
        this._resize();
        this._animate = this._animate.bind(this);
        this.running = true;
        requestAnimationFrame(this._animate);
    }

    _initParticles() {
        for (let i = 0; i < PARTICLE_COUNT; i++) {
            const y = 1 - (i / (PARTICLE_COUNT - 1)) * 2;
            const radius = Math.sqrt(1 - y * y);
            const theta = PHI * i;
            this.baseX[i] = Math.cos(theta) * radius;
            this.baseY[i] = y;
            this.baseZ[i] = Math.sin(theta) * radius;
            this.px[i] = this.baseX[i];
            this.py[i] = this.baseY[i];
            this.pz[i] = this.baseZ[i];
            this.vx[i] = 0;
            this.vy[i] = 0;
            this.sizes[i] = 1 + Math.random() * 2;
            this.alphas[i] = 0.3 + Math.random() * 0.7;
        }
    }

    _bindEvents() {
        window.addEventListener('resize', () => this._resize());
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const mx = e.clientX - rect.left;
            const my = e.clientY - rect.top;
            const dx = mx - this.lastMouseX;
            const dy = my - this.lastMouseY;
            this.mouseVelocity = Math.sqrt(dx * dx + dy * dy);
            this.lastMouseX = mx;
            this.lastMouseY = my;
        });
        this.canvas.addEventListener('mouseleave', () => { this.mouseVelocity = 0; });
    }

    _resize() {
        const wrapper = this.canvas.parentElement;
        const size = Math.min(wrapper.clientWidth, wrapper.clientHeight);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        this.canvas.width = size * dpr;
        this.canvas.height = size * dpr;
        this.canvas.style.width = size + 'px';
        this.canvas.style.height = size + 'px';
        this.ctx.scale(dpr, dpr);
        this.centerX = size / 2;
        this.centerY = size / 2;
        this.sphereRadius = size * 0.32;
    }

    _animate(timestamp) {
        if (!this.running) return;
        this.time += 0.016;
        this.turbulence += (Math.min(this.mouseVelocity * 0.05, 1) - this.turbulence) * 0.08;
        this.mouseVelocity *= 0.92;
        this.breathPhase += 0.02;

        const ctx = this.ctx;
        const w = this.canvas.width / (Math.min(window.devicePixelRatio || 1, 2));
        ctx.clearRect(0, 0, w, w);

        // Background glow
        const grad = ctx.createRadialGradient(this.centerX, this.centerY, 0, this.centerX, this.centerY, this.sphereRadius * 1.5);
        if (this.state === 'focus') {
            grad.addColorStop(0, 'rgba(0,245,212,0.06)');
            grad.addColorStop(1, 'transparent');
        } else {
            grad.addColorStop(0, 'rgba(178,75,243,0.04)');
            grad.addColorStop(1, 'transparent');
        }
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, w);

        this._updateParticles();
        this._drawParticles(ctx);

        requestAnimationFrame(this._animate);
    }

    _updateParticles() {
        const breathScale = this.state === 'focus' ? 1 + Math.sin(this.breathPhase) * 0.05 : 1;
        const rotSpeed = this.state === 'focus' ? 0.002 : 0.008;
        const chaos = this.state === 'idle' ? 0.3 + this.turbulence * 0.7 : this.turbulence * 0.3;

        for (let i = 0; i < PARTICLE_COUNT; i++) {
            // Rotate base positions
            const cosR = Math.cos(rotSpeed);
            const sinR = Math.sin(rotSpeed);
            const nx = this.baseX[i] * cosR - this.baseZ[i] * sinR;
            const nz = this.baseX[i] * sinR + this.baseZ[i] * cosR;
            this.baseX[i] = nx;
            this.baseZ[i] = nz;

            // Target position
            let tx = this.baseX[i] * this.sphereRadius * breathScale;
            let ty = this.baseY[i] * this.sphereRadius * breathScale;

            // Add wave distortion
            const waveFreq = this.state === 'focus' ? 2 : 4;
            const waveAmp = this.state === 'focus' ? 2 : 8 + chaos * 15;
            tx += Math.sin(this.baseY[i] * waveFreq + this.time * 2) * waveAmp * (0.5 + chaos);
            ty += Math.cos(this.baseX[i] * waveFreq + this.time * 1.5) * waveAmp * (0.3 + chaos);

            // Smooth interpolation
            const lerp = this.state === 'focus' ? 0.05 : 0.03;
            this.px[i] += (tx - this.px[i]) * lerp;
            this.py[i] += (ty - this.py[i]) * lerp;
        }
    }

    _drawParticles(ctx) {
        const tealR = 0, tealG = 245, tealB = 212;
        const violetR = 178, violetG = 75, violetB = 243;
        const amberR = 255, amberG = 107, amberB = 53;

        // Sort by z for depth
        const indices = Array.from({length: PARTICLE_COUNT}, (_, i) => i);
        indices.sort((a, b) => this.pz[a] - this.pz[b]);

        for (const i of indices) {
            const depth = (this.baseZ[i] + 1) / 2; // 0 to 1
            const screenX = this.centerX + this.px[i];
            const screenY = this.centerY + this.py[i];
            const size = this.sizes[i] * (0.5 + depth * 0.8);
            const alpha = this.alphas[i] * (0.2 + depth * 0.8);

            // Color based on state and depth
            let r, g, b;
            if (this.state === 'focus') {
                r = tealR; g = tealG; b = tealB;
            } else {
                const t = (Math.sin(this.time + i * 0.01) + 1) / 2;
                r = Math.round(violetR + (tealR - violetR) * t);
                g = Math.round(violetG + (tealG - violetG) * t);
                b = Math.round(violetB + (tealB - violetB) * t);
            }

            // Glow
            if (size > 1.5 && depth > 0.6) {
                ctx.beginPath();
                ctx.arc(screenX, screenY, size * 3, 0, TAU);
                ctx.fillStyle = `rgba(${r},${g},${b},${alpha * 0.1})`;
                ctx.fill();
            }

            ctx.beginPath();
            ctx.arc(screenX, screenY, size, 0, TAU);
            ctx.fillStyle = `rgba(${r},${g},${b},${alpha})`;
            ctx.fill();
        }
    }

    setState(newState) {
        this.state = newState;
        if (newState === 'complete') {
            this._explode();
        }
    }

    _explode() {
        // Particles fly outward for celebration
        const explosionParticles = [];
        const canvas = document.getElementById('celebrationCanvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth * 2;
        canvas.height = window.innerHeight * 2;
        canvas.style.width = window.innerWidth + 'px';
        canvas.style.height = window.innerHeight + 'px';

        const colors = ['#00f5d4', '#b24bf3', '#ff6b35', '#ff2d95', '#6ee7b7'];
        for (let i = 0; i < 200; i++) {
            const angle = Math.random() * TAU;
            const speed = 3 + Math.random() * 8;
            explosionParticles.push({
                x: window.innerWidth / 2 * 2,
                y: window.innerHeight / 2 * 2,
                vx: Math.cos(angle) * speed * 2,
                vy: Math.sin(angle) * speed * 2 - 3,
                size: 2 + Math.random() * 6,
                color: colors[Math.floor(Math.random() * colors.length)],
                alpha: 1,
                decay: 0.008 + Math.random() * 0.015
            });
        }

        let frame = 0;
        const animateExplosion = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            let alive = false;
            for (const p of explosionParticles) {
                p.x += p.vx;
                p.y += p.vy;
                p.vy += 0.15; // gravity
                p.alpha -= p.decay;
                if (p.alpha > 0) {
                    alive = true;
                    ctx.globalAlpha = p.alpha;
                    ctx.fillStyle = p.color;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.size, 0, TAU);
                    ctx.fill();
                }
            }
            ctx.globalAlpha = 1;
            if (alive && frame < 180) {
                frame++;
                requestAnimationFrame(animateExplosion);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        };
        requestAnimationFrame(animateExplosion);
        this.state = 'idle';
    }

    destroy() {
        this.running = false;
    }
}
