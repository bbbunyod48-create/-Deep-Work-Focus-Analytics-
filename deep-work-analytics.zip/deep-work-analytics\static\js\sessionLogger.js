/**
 * Holographic Flow Session Logger
 * ================================
 * Cyberpunk task input with scanline glow effects,
 * FLIP morph animations, and native drag-and-sort.
 */

export class SessionLogger {
    constructor() {
        this.form = document.getElementById('taskInputForm');
        this.input = document.getElementById('taskInput');
        this.list = document.getElementById('taskList');
        this.empty = document.getElementById('taskListEmpty');
        this.categoryBtns = document.querySelectorAll('.category-btn');
        this.selectedCategory = 'general';
        this.tasks = [];
        this.dragItem = null;
        this.dragIndex = -1;

        this._bindEvents();
        this._loadTasks();
    }

    _bindEvents() {
        // Form submit
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this._addTask();
        });

        // Category selection
        this.categoryBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                this.categoryBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.selectedCategory = btn.dataset.category;
            });
        });

        // Typing glow effect
        this.input.addEventListener('input', () => {
            this.input.classList.add('typing');
            clearTimeout(this._typingTimeout);
            this._typingTimeout = setTimeout(() => {
                this.input.classList.remove('typing');
            }, 300);
        });
    }

    async _loadTasks() {
        try {
            const res = await fetch('/api/tasks');
            if (res.ok) {
                this.tasks = await res.json();
                this._renderList();
            }
        } catch (e) { /* use empty list */ }
    }

    async _addTask() {
        const title = this.input.value.trim();
        if (!title) return;

        try {
            const res = await fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, category: this.selectedCategory })
            });
            if (res.ok) {
                const task = await res.json();
                this.tasks.unshift(task);
                this.input.value = '';
                this._renderList();
            }
        } catch (e) {
            // Offline fallback: add locally
            this.tasks.unshift({
                id: Date.now(), title, category: this.selectedCategory,
                completed: 0, sort_order: 0, created_at: new Date().toISOString()
            });
            this.input.value = '';
            this._renderList();
        }
    }

    async _toggleTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (!task) return;
        task.completed = task.completed ? 0 : 1;
        this._renderList();
        try {
            await fetch(`/api/tasks/${taskId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ completed: !!task.completed })
            });
        } catch (e) { /* silent */ }
    }

    async _deleteTask(taskId) {
        this.tasks = this.tasks.filter(t => t.id !== taskId);
        this._renderList();
        try {
            await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' });
        } catch (e) { /* silent */ }
    }

    _renderList() {
        this.list.innerHTML = '';
        this.empty.style.display = this.tasks.length === 0 ? 'block' : 'none';

        this.tasks.forEach((task, index) => {
            const li = document.createElement('li');
            li.className = `task-item${task.completed ? ' completed' : ''}`;
            li.setAttribute('data-id', task.id);
            li.setAttribute('draggable', 'true');

            li.innerHTML = `
                <div class="task-checkbox ${task.completed ? 'checked' : ''}" data-action="toggle"></div>
                <span class="task-title">${this._escapeHtml(task.title)}</span>
                <span class="task-category" data-cat="${task.category}">${task.category}</span>
                <button class="task-delete" data-action="delete" title="Delete">×</button>
            `;

            // Click handlers
            li.querySelector('[data-action="toggle"]').addEventListener('click', () => {
                this._toggleTask(task.id);
            });
            li.querySelector('[data-action="delete"]').addEventListener('click', () => {
                this._deleteTask(task.id);
            });

            // Drag events
            li.addEventListener('dragstart', (e) => {
                this.dragItem = li;
                this.dragIndex = index;
                li.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            });
            li.addEventListener('dragend', () => {
                li.classList.remove('dragging');
                this.dragItem = null;
            });
            li.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                li.classList.add('drag-over');
            });
            li.addEventListener('dragleave', () => {
                li.classList.remove('drag-over');
            });
            li.addEventListener('drop', (e) => {
                e.preventDefault();
                li.classList.remove('drag-over');
                if (this.dragIndex !== index) {
                    const [moved] = this.tasks.splice(this.dragIndex, 1);
                    this.tasks.splice(index, 0, moved);
                    this._renderList();
                }
            });

            this.list.appendChild(li);
        });
    }

    _escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
}
