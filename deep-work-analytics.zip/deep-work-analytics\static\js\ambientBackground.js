/**
 * Ambient Background Particles
 * ==============================
 * Subtle floating particles across the entire app background
 * for a living, breathing atmosphere. Uses a dedicated canvas.
 */

export class AmbientBackground {
    constructor() {
        this.canvas = document.createElement('canvas');
        this.canvas.className = 'ambient-canvas';
        this.canvas.style.cssText = 'position:fixed;inset:0;z-index:-1;pointer-events:none;opacity:0.6';
        document.body.prepend(this.canvas);
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.mouse = { x: -1000, y: -1000 };
        this.count = 80;

        this._resize();
        this._initParticles();
        this._bindEvents();
        this._animate();
    }

    _resize() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        this.w = window.innerWidth;
        this.h = window.innerHeight;
        this.canvas.width = this.w * dpr;
        this.canvas.height = this.h * dpr;
        this.canvas.style.width = this.w + 'px';
        this.canvas.style.height = this.h + 'px';
        this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    _initParticles() {
        const colors = [
            { r: 0, g: 245, b: 212 },   // teal
            { r: 178, g: 75, b: 243 },   // violet
            { r: 255, g: 107, b: 53 },   // amber
        ];
        this.particles = [];
        for (let i = 0; i < this.count; i++) {
            const c = colors[Math.floor(Math.random() * colors.length)];
            this.particles.push({
                x: Math.random() * this.w,
                y: Math.random() * this.h,
                vx: (Math.random() - 0.5) * 0.3,
                vy: (Math.random() - 0.5) * 0.3,
                size: 1 + Math.random() * 2,
                alpha: 0.1 + Math.random() * 0.3,
                color: c,
                pulse: Math.random() * Math.PI * 2
            });
        }
    }

    _bindEvents() {
        window.addEventListener('resize', () => this._resize());
        window.addEventListener('mousemove', (e) => {
            this.mouse.x = e.clientX;
            this.mouse.y = e.clientY;
        });
    }

    _animate() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.w, this.h);

        for (const p of this.particles) {
            p.x += p.vx;
            p.y += p.vy;
            p.pulse += 0.01;

            // Wrap around
            if (p.x < -10) p.x = this.w + 10;
            if (p.x > this.w + 10) p.x = -10;
            if (p.y < -10) p.y = this.h + 10;
            if (p.y > this.h + 10) p.y = -10;

            // Mouse repulsion
            const dx = p.x - this.mouse.x;
            const dy = p.y - this.mouse.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 120) {
                const force = (120 - dist) / 120 * 0.5;
                p.vx += (dx / dist) * force;
                p.vy += (dy / dist) * force;
            }

            // Dampen velocity
            p.vx *= 0.99;
            p.vy *= 0.99;

            const alpha = p.alpha * (0.5 + Math.sin(p.pulse) * 0.5);

            // Glow
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * 4, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${p.color.r},${p.color.g},${p.color.b},${alpha * 0.15})`;
            ctx.fill();

            // Core
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${p.color.r},${p.color.g},${p.color.b},${alpha})`;
            ctx.fill();
        }

        // Draw connection lines between nearby particles
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const a = this.particles[i];
                const b = this.particles[j];
                const dx = a.x - b.x;
                const dy = a.y - b.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 150) {
                    const alpha = (1 - dist / 150) * 0.08;
                    ctx.beginPath();
                    ctx.moveTo(a.x, a.y);
                    ctx.lineTo(b.x, b.y);
                    ctx.strokeStyle = `rgba(0,245,212,${alpha})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }

        requestAnimationFrame(() => this._animate());
    }
}
