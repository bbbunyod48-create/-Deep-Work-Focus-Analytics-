/**
 * Deep Work & Focus Analytics — Main Controller
 * ================================================
 * Orchestrates all modules, handles navigation,
 * timer logic, and global state management.
 */

import { ParticleSphere } from './particleSphere.js';
import { BonsaiGuardian } from './bonsaiGuardian.js';
import { AudioMatrix } from './audioMatrix.js';
import { AnalyticsGrid } from './analyticsGrid.js';
import { SessionLogger } from './sessionLogger.js';

// ──────────────────────────────────────────────
// State
// ──────────────────────────────────────────────
const state = {
    currentSection: 'focus',
    timer: {
        targetMinutes: 25,
        remainingSeconds: 25 * 60,
        isRunning: false,
        isPaused: false,
        sessionId: null,
        interval: null
    }
};

// ──────────────────────────────────────────────
// Module Instances
// ──────────────────────────────────────────────
let sphere, bonsai, audio, analytics, logger;

// ──────────────────────────────────────────────
// Navigation
// ──────────────────────────────────────────────
function initNavigation() {
    const navBtns = document.querySelectorAll('.nav-btn');
    const sections = document.querySelectorAll('.section');

    navBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.dataset.section;
            if (target === state.currentSection) return;

            // Update nav
            navBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            // Update sections
            sections.forEach(s => s.classList.remove('section--active'));
            const targetSection = document.getElementById('section' + capitalize(target));
            if (targetSection) targetSection.classList.add('section--active');

            state.currentSection = target;

            // Trigger section-specific actions
            if (target === 'analytics') analytics.show();
        });
    });
}

function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// ──────────────────────────────────────────────
// Timer Logic
// ──────────────────────────────────────────────
function initTimer() {
    const display = document.getElementById('timerDisplay');
    const label = document.getElementById('timerLabel');
    const btnStart = document.getElementById('btnStartFocus');
    const btnPause = document.getElementById('btnPauseFocus');
    const btnStop = document.getElementById('btnStopFocus');
    const durationBtns = document.querySelectorAll('.duration-btn');
    const statusDot = document.querySelector('.status-dot');
    const statusText = document.querySelector('.status-text');

    // Duration selector
    durationBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (state.timer.isRunning) return;
            durationBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            state.timer.targetMinutes = parseInt(btn.dataset.minutes);
            state.timer.remainingSeconds = state.timer.targetMinutes * 60;
            updateDisplay();
        });
    });

    function updateDisplay() {
        const mins = Math.floor(state.timer.remainingSeconds / 60);
        const secs = state.timer.remainingSeconds % 60;
        display.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }

    // Start
    btnStart.addEventListener('click', async () => {
        if (state.timer.isRunning) return;
        state.timer.isRunning = true;
        state.timer.isPaused = false;
        state.timer.remainingSeconds = state.timer.targetMinutes * 60;

        // Create session in backend
        try {
            const res = await fetch('/api/sessions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ target_minutes: state.timer.targetMinutes })
            });
            if (res.ok) {
                const data = await res.json();
                state.timer.sessionId = data.id;
            }
        } catch (e) { /* offline mode */ }

        sphere.setState('focus');
        label.textContent = 'Deep Work in Progress';
        btnStart.style.display = 'none';
        btnPause.style.display = 'inline-flex';
        btnStop.style.display = 'inline-flex';
        statusDot.classList.add('active');
        statusText.textContent = 'Focus';

        state.timer.interval = setInterval(() => {
            if (state.timer.isPaused) return;
            state.timer.remainingSeconds--;
            updateDisplay();

            if (state.timer.remainingSeconds <= 0) {
                completeSession();
            }
        }, 1000);
    });

    // Pause
    btnPause.addEventListener('click', () => {
        state.timer.isPaused = !state.timer.isPaused;
        btnPause.querySelector('.btn-text').textContent = state.timer.isPaused ? 'Resume' : 'Pause';
        label.textContent = state.timer.isPaused ? 'Paused' : 'Deep Work in Progress';
        if (state.timer.isPaused) {
            sphere.setState('idle');
        } else {
            sphere.setState('focus');
        }
    });

    // Stop
    btnStop.addEventListener('click', () => {
        endSession(false);
    });

    async function completeSession() {
        endSession(true);
        sphere.setState('complete');
        label.textContent = 'Session Complete! 🎉';

        // Grow bonsai
        bonsai.addFocusMinutes(state.timer.targetMinutes);
    }

    async function endSession(completed) {
        clearInterval(state.timer.interval);
        state.timer.isRunning = false;
        state.timer.isPaused = false;

        const elapsed = state.timer.targetMinutes * 60 - state.timer.remainingSeconds;

        // Update backend
        if (state.timer.sessionId) {
            try {
                await fetch(`/api/sessions/${state.timer.sessionId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        end_time: new Date().toISOString(),
                        duration_seconds: elapsed,
                        completed
                    })
                });
            } catch (e) { /* silent */ }
        }

        // Reset UI
        state.timer.remainingSeconds = state.timer.targetMinutes * 60;
        updateDisplay();
        if (!completed) {
            sphere.setState('idle');
            label.textContent = 'Ready to Focus';
        }
        btnStart.style.display = 'inline-flex';
        btnPause.style.display = 'none';
        btnStop.style.display = 'none';
        btnPause.querySelector('.btn-text').textContent = 'Pause';
        statusDot.classList.remove('active');
        statusText.textContent = 'Idle';

        // Refresh analytics
        analytics.reset();
    }

    updateDisplay();
}

// ──────────────────────────────────────────────
// Audio Toggle Button
// ──────────────────────────────────────────────
function initAudioToggle() {
    const btn = document.getElementById('btnToggleAudio');
    btn.addEventListener('click', async () => {
        const active = await audio.toggle();
        btn.querySelector('.btn-text').textContent = active ? 'Stop Audio Engine' : 'Initialize Audio Engine';
        if (active) {
            btn.classList.add('btn--danger');
            btn.classList.remove('btn--primary');
        } else {
            btn.classList.remove('btn--danger');
            btn.classList.add('btn--primary');
        }
    });
}

// ──────────────────────────────────────────────
// Initialize Everything
// ──────────────────────────────────────────────
function init() {
    sphere = new ParticleSphere('particleCanvas');
    bonsai = new BonsaiGuardian();
    audio = new AudioMatrix('audioCanvas');
    analytics = new AnalyticsGrid();
    logger = new SessionLogger();

    initNavigation();
    initTimer();
    initAudioToggle();

    // Pre-load analytics data
    analytics.loadData();

    console.log('%c⚡ Deep Work Analytics initialized', 'color:#00f5d4;font-size:14px;font-weight:bold');
}

// Boot
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}
